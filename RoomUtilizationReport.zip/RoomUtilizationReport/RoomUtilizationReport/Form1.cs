﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace RoomUtilizationReport
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Populate the Data Grid view with the data retrieved from the database !
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonGenerate_Click(object sender, EventArgs e)
        {
            LabelHeader.Text = $"Room Utilization Report  ({DateTimePicker.Text})"; // Change the date in the Main Header !

            // Database Connection String Which specify the name, server and other shit !
            string connectionString = "Data Source=himanshu\\dc;Initial Catalog=lakeridge;Integrated Security=True";

            // Now using the 'using' synatx which is used to free up the resources after the use !
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open(); //Opening the Connection !

                // SQL query to retrieve data for DataGridView
                string query = @"
                SELECT
                patient.room_num + patient.bed_letter AS Location,
                bed.bed_type as Type,
                patient.patient_no AS [Patient-No],
                patient.patient_first_name + ', ' + patient.patient_last_name AS [Patient-Name],
                CONVERT(VARCHAR(10), patient.date_admitted, 101) AS [Date-Admitted]
            FROM
                patient
                JOIN bed ON patient.room_num = bed.room_num AND patient.bed_letter = bed.bed_letter
                ;
        ";

                // Creating the object of SqlCommand which will let us communicate us with the database !
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Now Creating withe Object of SqlDataAdapter Class Which will helps us getting data in and out of the database !
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        // Creating the object of DataTable Class Which is nothing but rows and columns of data !
                        DataTable dataTable = new DataTable();
                        // Using the property of the SqlAdapter Class populating the datatable with the data fetched from the Database !
                        adapter.Fill(dataTable);

                        // Clear the previous data source !
                        DataGridViewRoomReport.DataSource = null;

                        // Setting the data source for the dataGrid View !
                        DataGridViewRoomReport.DataSource = dataTable;
                    }
                }
            }
        }

        /// <summary>
        ///  When the Form Loads !
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            // Creating the Array of Columns Object !
            DataGridViewTextBoxColumn[] columns =
            {
            new DataGridViewTextBoxColumn() { HeaderText = "Location", DataPropertyName = "Location", Width = 179, ReadOnly = true },
            new DataGridViewTextBoxColumn() { HeaderText = "Type", DataPropertyName = "Type", Width = 150, ReadOnly = true },
            new DataGridViewTextBoxColumn() { HeaderText = "Patient-No", DataPropertyName = "Patient-No", Width = 150, ReadOnly = true },
            new DataGridViewTextBoxColumn() { HeaderText = "Patient-Name", DataPropertyName = "Patient-Name", Width = 180, ReadOnly = true },
            new DataGridViewTextBoxColumn() { HeaderText = "Date-Admitted", DataPropertyName = "Date-Admitted", Width = 150, ReadOnly = true }
             };

            // Adding each column to the data grid view!
            foreach (DataGridViewTextBoxColumn column in columns)
            {
                DataGridViewRoomReport.Columns.Add(column);
            }

            // Setting some property for the DataGrid View !
            DataGridViewRoomReport.AutoGenerateColumns = false;
            DataGridViewRoomReport.ReadOnly = true;
        }

    }
}
