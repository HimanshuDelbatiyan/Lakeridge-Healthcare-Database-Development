﻿namespace RoomUtilizationReport
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabelDate = new System.Windows.Forms.Label();
            this.LabelHeader = new System.Windows.Forms.Label();
            this.DateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.ButtonGenerate = new System.Windows.Forms.Button();
            this.DataGridViewRoomReport = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewRoomReport)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelDate
            // 
            this.LabelDate.AutoSize = true;
            this.LabelDate.Location = new System.Drawing.Point(12, 93);
            this.LabelDate.Name = "LabelDate";
            this.LabelDate.Size = new System.Drawing.Size(162, 29);
            this.LabelDate.TabIndex = 2;
            this.LabelDate.Text = "Select Date: ";
            // 
            // LabelHeader
            // 
            this.LabelHeader.AutoSize = true;
            this.LabelHeader.Font = new System.Drawing.Font("Modern No. 20", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelHeader.Location = new System.Drawing.Point(82, 28);
            this.LabelHeader.Name = "LabelHeader";
            this.LabelHeader.Size = new System.Drawing.Size(443, 41);
            this.LabelHeader.TabIndex = 3;
            this.LabelHeader.Text = "Room Utilization Report";
            // 
            // DateTimePicker
            // 
            this.DateTimePicker.Location = new System.Drawing.Point(180, 88);
            this.DateTimePicker.Name = "DateTimePicker";
            this.DateTimePicker.Size = new System.Drawing.Size(288, 34);
            this.DateTimePicker.TabIndex = 4;
            // 
            // ButtonGenerate
            // 
            this.ButtonGenerate.Location = new System.Drawing.Point(694, 653);
            this.ButtonGenerate.Name = "ButtonGenerate";
            this.ButtonGenerate.Size = new System.Drawing.Size(133, 38);
            this.ButtonGenerate.TabIndex = 5;
            this.ButtonGenerate.Text = "Generate";
            this.ButtonGenerate.UseVisualStyleBackColor = true;
            this.ButtonGenerate.Click += new System.EventHandler(this.ButtonGenerate_Click);
            // 
            // DataGridViewRoomReport
            // 
            this.DataGridViewRoomReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewRoomReport.Location = new System.Drawing.Point(12, 142);
            this.DataGridViewRoomReport.Name = "DataGridViewRoomReport";
            this.DataGridViewRoomReport.RowHeadersWidth = 51;
            this.DataGridViewRoomReport.RowTemplate.Height = 24;
            this.DataGridViewRoomReport.Size = new System.Drawing.Size(868, 493);
            this.DataGridViewRoomReport.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 719);
            this.Controls.Add(this.DataGridViewRoomReport);
            this.Controls.Add(this.ButtonGenerate);
            this.Controls.Add(this.DateTimePicker);
            this.Controls.Add(this.LabelHeader);
            this.Controls.Add(this.LabelDate);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form1";
            this.Text = "Lakeridge Health Care";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewRoomReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LabelDate;
        private System.Windows.Forms.Label LabelHeader;
        private System.Windows.Forms.DateTimePicker DateTimePicker;
        private System.Windows.Forms.Button ButtonGenerate;
        private System.Windows.Forms.DataGridView DataGridViewRoomReport;
    }
}

